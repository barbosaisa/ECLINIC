import { useState, useEffect } from "react";
import "./cliente.css";

export default function Cliente({ voltar, consultas, setConsultas }) {
  const [aba, setAba] = useState("home");

  const [menuAberto, setMenuAberto] = useState(false);

  // =========================
  // AGENDAMENTO
  // =========================
  const [data, setData] = useState("");

  const [hora, setHora] = useState("");

  const [estagiario, setEstagiario] = useState("");

  const [horariosDisponiveis, setHorariosDisponiveis] = useState([]);

  // =========================
  // PRÓXIMA CONSULTA
  // =========================
  const proximaConsulta = consultas.length > 0 ? consultas[0] : null;

  // =========================
  // CONTADOR
  // =========================
  function calcularTempoRestante() {
    if (!proximaConsulta) return null;

    const agora = new Date();

    const consulta = new Date(
      `${proximaConsulta.data}T${proximaConsulta.hora}`
    );

    const diferenca = consulta - agora;

    if (diferenca <= 0) return "Em breve";

    const horas = Math.floor(diferenca / 1000 / 60 / 60);

    const minutos = Math.floor((diferenca / 1000 / 60) % 60);

    return `${horas}h ${minutos}m`;
  }

  // =========================
  // HORÁRIOS
  // =========================
  useEffect(() => {
    if (!data) {
      setHorariosDisponiveis([]);

      return;
    }

    const dataObj = new Date(data + "T00:00:00");

    const diaSemana = dataObj.getDay();

    if (diaSemana === 0) {
      setHorariosDisponiveis([]);

      return;
    }

    let inicio = 8;

    let fim = 20;

    if (diaSemana === 6) fim = 14;

    if (diaSemana === 3) fim = 18;

    let lista = [];

    for (let h = inicio; h < fim; h++) {
      if (diaSemana !== 3 && h >= 13 && h < 16) continue;

      lista.push(`${h.toString().padStart(2, "0")}:00`);
    }

    const ocupados = consultas
      .filter((c) => c.data === data)
      .map((c) => c.hora);

    const livres = lista.filter((h) => !ocupados.includes(h));

    setHorariosDisponiveis(livres);
  }, [data, consultas]);

  // =========================
  // AGENDAR
  // =========================
  function agendar() {
    if (!data || !hora || !estagiario) {
      alert("Preencha todos os campos");

      return;
    }

    const nova = {
      data,

      hora,

      estagiario,

      paciente: "Paciente",

      sala: "Sala 0" + (Math.floor(Math.random() * 5) + 1),

      status: "Agendado",
    };

    setConsultas([...consultas, nova]);

    alert("Consulta agendada!");

    setData("");

    setHora("");

    setEstagiario("");

    setAba("consultas");
  }

  return (
    <div className="cliente-page">
      <div className="cliente-wrapper">
        {/* SIDEBAR */}
        <div className={`cliente-sidebar ${menuAberto ? "open" : ""}`}>
          <div className="cliente-sidebar-top">
            <div className="cliente-sidebar-logo">E</div>

            <div>
              <h3>Área do Paciente</h3>

              <p>E-Clinic</p>
            </div>
          </div>

          <div className="cliente-sidebar-links">
            <button
              className={
                aba === "home"
                  ? "cliente-side-link active"
                  : "cliente-side-link"
              }
              onClick={() => {
                setAba("home");

                setMenuAberto(false);
              }}
            >
              Início
            </button>

            <button
              className={
                aba === "agenda"
                  ? "cliente-side-link active"
                  : "cliente-side-link"
              }
              onClick={() => {
                setAba("agenda");

                setMenuAberto(false);
              }}
            >
              Agendar
            </button>

            <button
              className={
                aba === "consultas"
                  ? "cliente-side-link active"
                  : "cliente-side-link"
              }
              onClick={() => {
                setAba("consultas");

                setMenuAberto(false);
              }}
            >
              Consultas
            </button>

            <button
              className={
                aba === "lembretes"
                  ? "cliente-side-link active"
                  : "cliente-side-link"
              }
              onClick={() => {
                setAba("lembretes");

                setMenuAberto(false);
              }}
            >
              Lembretes
            </button>

            <button className="cliente-side-link logout" onClick={voltar}>
              Sair
            </button>
          </div>
        </div>

        {/* OVERLAY */}
        {menuAberto && (
          <div
            className="cliente-overlay"
            onClick={() => setMenuAberto(false)}
          />
        )}

        {/* HEADER */}
        <header className="cliente-header">
          <button
            className="cliente-menu-button"
            onClick={() => setMenuAberto(true)}
          >
            ☰
          </button>

          <h2>Área do Paciente</h2>
        </header>

        {/* MAIN */}
        <main className="cliente-main">
          {/* HOME */}
          {aba === "home" && (
            <div className="cliente-content">
              <h2>Olá Paciente!</h2>

              <p>Gerencie suas consultas</p>

              {/* CARDS */}
              <div className="cliente-home-cards">
                <div className="cliente-home-card">
                  <strong>{consultas.length}</strong>

                  <p>Consultas</p>
                </div>

                <div className="cliente-home-card">
                  <strong>
                    {
                      consultas.filter(
                        (c) => c.data === new Date().toISOString().split("T")[0]
                      ).length
                    }
                  </strong>

                  <p>Hoje</p>
                </div>
              </div>

              {/* PRÓXIMA CONSULTA */}
              <div className="cliente-next-card">
                <h3>Próxima Sessão</h3>

                {proximaConsulta ? (
                  <>
                    <strong>{proximaConsulta.estagiario}</strong>

                    <p>
                      {proximaConsulta.data}
                      {" • "}
                      {proximaConsulta.hora}
                    </p>

                    <div className="contador-consulta">
                      Sua próxima consulta começa em:
                      <span>{calcularTempoRestante()}</span>
                    </div>
                  </>
                ) : (
                  <p>Nenhuma consulta agendada</p>
                )}
              </div>

              {/* BANNER */}
              <div className="cliente-banner-card">
                <img
                  src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?q=80&w=1200&auto=format&fit=crop"
                  alt="Banner"
                />

                <div className="cliente-banner-overlay">
                  <h3>Cuide da sua saúde mental</h3>

                  <p>Pequenos cuidados diários fazem diferença.</p>
                </div>
              </div>
            </div>
          )}

          {/* AGENDAR */}
          {aba === "agenda" && (
            <div className="cliente-form-container">
              <h3>Agendamento</h3>

              <label>Data</label>

              <input
                type="date"
                value={data}
                onChange={(e) => {
                  setData(e.target.value);

                  setHora("");
                }}
              />

              <label>Horário</label>

              <div className="horarios-grid">
                {horariosDisponiveis.length > 0 ? (
                  horariosDisponiveis.map((h) => (
                    <button
                      key={h}
                      className={`horario-btn ${hora === h ? "active" : ""}`}
                      onClick={() => setHora(h)}
                    >
                      {h}
                    </button>
                  ))
                ) : (
                  <p></p>
                )}
              </div>

              <label>Estagiário</label>

              <select
                value={estagiario}
                onChange={(e) => setEstagiario(e.target.value)}
              >
                <option value="">Selecione</option>

                <option value="João Silva">João Silva</option>

                <option value="Maria Oliveira">Maria Oliveira</option>
              </select>

              <button onClick={agendar}>Confirmar</button>
            </div>
          )}

          {/* CONSULTAS */}
          {aba === "consultas" && (
            <div className="cliente-list">
              <h3>Minhas Sessões</h3>

              {consultas.length > 0 ? (
                consultas.map((c, i) => (
                  <div key={i} className="cliente-card">
                    <strong>{c.estagiario}</strong>

                    <p>
                      {c.data}
                      {" - "}
                      {c.hora}
                    </p>

                    <span>{c.status}</span>
                  </div>
                ))
              ) : (
                <p>Nenhuma sessão</p>
              )}
            </div>
          )}

          {/* LEMBRETES */}
          {aba === "lembretes" && (
            <div className="cliente-list">
              <h3>Seus Lembretes</h3>

              {consultas.length > 0 ? (
                consultas.map((c, i) => (
                  <div key={i} className="cliente-next-card">
                    <h3>Consulta Agendada</h3>

                    <strong>{c.estagiario}</strong>

                    <p>
                      {c.data}
                      {" • "}
                      {c.hora}
                    </p>

                    <small
                      style={{
                        color: "rgba(255,255,255,0.85)",
                      }}
                    >
                      Chegue 10 minutos antes.
                    </small>
                  </div>
                ))
              ) : (
                <p>Nenhuma consulta marcada</p>
              )}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
