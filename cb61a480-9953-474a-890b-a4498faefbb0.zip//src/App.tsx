import { useState, useEffect } from "react";
import "./styles.css";
import Estagiario from "./Estagiario";
import Administrador from "./Administrador";
import Cliente from "./Cliente";

export default function App() {
  const [carregando, setCarregando] = useState(true);
  const [tela, setTela] = useState("login");

  // ESTADOS GLOBAIS
  const [consultas, setConsultas] = useState([]);
  const [avaliacoes, setAvaliacoes] = useState([]);

  // LOGIN
  const [tipo, setTipo] = useState("Estagiário");
  const [login, setLogin] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState("");

  // CADASTRO
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [senhaCadastro, setSenhaCadastro] = useState("");

  useEffect(() => {
    setTimeout(() => {
      setCarregando(false);
    }, 2000);
  }, []);

  function entrar() {
    if (login === "admin" && senha === "123") {
      return setTela("admin");
    }

    if (login === "user" && senha === "123") {
      return setTela("estagiario");
    }

    if (login === "cliente" && senha === "123") {
      return setTela("cliente");
    }

    setErro("Login ou senha inválidos");
  }

  function cadastrar() {
    if (!nome || !email || !senhaCadastro) {
      alert("Preencha todos os campos!");
      return;
    }

    alert("Cadastro realizado com sucesso!");

    setTela("login");

    setNome("");
    setEmail("");
    setSenhaCadastro("");
  }

  // SPLASH
  if (carregando) {
    return (
      <div className="splash">
        <div className="logo-circle">E</div>

        <h1>E-Clinic</h1>

        <p>Sistema Clínico Mobile</p>
      </div>
    );
  }

  // ADMIN
  if (tela === "admin") {
    return (
      <Administrador
        voltar={() => setTela("login")}
        consultas={consultas}
        avaliacoes={avaliacoes}
      />
    );
  }

  // ESTAGIÁRIO
  if (tela === "estagiario") {
    return (
      <Estagiario
        voltar={() => setTela("login")}
        consultas={consultas}
        setConsultas={setConsultas}
        avaliacoes={avaliacoes}
      />
    );
  }

  // CLIENTE
  if (tela === "cliente") {
    return (
      <Cliente
        voltar={() => setTela("login")}
        consultas={consultas}
        setConsultas={setConsultas}
        avaliacoes={avaliacoes}
        setAvaliacoes={setAvaliacoes}
      />
    );
  }

  // CADASTRO
  if (tela === "cadastro") {
    return (
      <div className="app">
        <div className="blur blur-1"></div>
        <div className="blur blur-2"></div>

        <div className="login-card">
          <div className="logo-circle">E</div>

          <h1 className="titulo">Criar conta</h1>

          <p className="subtitle">Cadastre-se no sistema</p>

          <input
            type="text"
            placeholder="Nome completo"
            value={nome}
            onChange={(e) => setNome(e.target.value)}
          />

          <input
            type="email"
            placeholder="Seu email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <input
            type="password"
            placeholder="Senha"
            value={senhaCadastro}
            onChange={(e) => setSenhaCadastro(e.target.value)}
          />

          <button onClick={cadastrar}>Cadastrar</button>

          <p className="link" onClick={() => setTela("login")}>
            Já possui conta?
          </p>
        </div>
      </div>
    );
  }

  // LOGIN
  return (
    <div className="app">
      <div className="blur blur-1"></div>
      <div className="blur blur-2"></div>

      <div className="login-card">
        <div className="logo-circle">E</div>

        <h1 className="titulo">Bem-vindo</h1>

        <p className="subtitle">Acesse sua conta</p>

        <select value={tipo} onChange={(e) => setTipo(e.target.value)}>
          <option>Estagiário</option>
          <option>Administrador</option>
          <option>Paciente</option>
        </select>

        <input
          type="text"
          placeholder="Login ou matrícula"
          value={login}
          onChange={(e) => setLogin(e.target.value)}
        />

        <input
          type="password"
          placeholder="Senha"
          value={senha}
          onChange={(e) => setSenha(e.target.value)}
        />

        {erro && <p className="erro">{erro}</p>}

        <button onClick={entrar}>Entrar</button>

        <p className="link" onClick={() => setTela("cadastro")}>
          Cadastre-se
        </p>
      </div>
    </div>
  );
}
