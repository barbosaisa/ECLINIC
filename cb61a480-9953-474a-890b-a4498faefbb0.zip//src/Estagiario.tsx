import { useState } from "react";
import "./styles/estagiario.css";

export default function Estagiario({
  voltar,
  consultas,
  setConsultas,
  avaliacoes,
}) {
  const [aba, setAba] = useState("home");

  const [menuAberto, setMenuAberto] = useState(false);

  const nomeEstagiario = "João Silva";

  // =========================
  // STATUS
  // =========================
  function atualizarStatus(index) {
    const novas = [...consultas];

    if (novas[index].status === "Agendado") {
      novas[index].status = "Em atendimento";
    } else if (novas[index].status === "Em atendimento") {
      novas[index].status = "Finalizado";
    }

    setConsultas(novas);
  }

  // =========================
  // FILTRA AVALIAÇÕES
  // =========================
  const minhasAvaliacoes = (avaliacoes || []).filter(
    (a) =>
      a.estagiario?.toLowerCase().trim() === nomeEstagiario.toLowerCase().trim()
  );

  // =========================
  // MÉDIA
  // =========================
  function calcularMedia() {
    if (!minhasAvaliacoes.length) return "0.0";

    const soma = minhasAvaliacoes.reduce((acc, a) => acc + a.nota, 0);

    return (soma / minhasAvaliacoes.length).toFixed(1);
  }

  // =========================
  // TOTAL PACIENTES
  // =========================
  function totalPacientes() {
    return consultas.length;
  }

  return (
    <div className="estag-wrapper">
      <div className="estag-mobile-app">
        {/* SIDEBAR */}
        <div className={`sidebar ${menuAberto ? "open" : ""}`}>
          <div className="sidebar-top">
            <div className="sidebar-logo">E</div>

            <div>
              <h3>Área do Estagiário</h3>

              <p>E-Clinic</p>
            </div>
          </div>

          <div className="sidebar-links">
            <button
              className={aba === "home" ? "side-link active" : "side-link"}
              onClick={() => {
                setAba("home");
                setMenuAberto(false);
              }}
            >
              Início
            </button>

            <button
              className={aba === "perfil" ? "side-link active" : "side-link"}
              onClick={() => {
                setAba("perfil");
                setMenuAberto(false);
              }}
            >
              Perfil
            </button>

            <button className="side-link logout" onClick={voltar}>
              Sair
            </button>
          </div>
        </div>

        {/* OVERLAY */}
        {menuAberto && (
          <div className="overlay" onClick={() => setMenuAberto(false)} />
        )}

        {/* HEADER */}
        <header className="estag-header">
          <button className="menu-button" onClick={() => setMenuAberto(true)}>
            ☰
          </button>

          <h2>Área do Estagiário</h2>
        </header>

        {/* MAIN */}
        <main className="estag-main">
          {/* HOME */}
          {aba === "home" && (
            <>
              <section className="estag-hero">
                <h2>Olá, Estagiário! </h2>

                <p>Seus atendimentos de hoje</p>
              </section>

              <div className="estag-list-section">
                <h3>Agenda do Dia</h3>

                {consultas.length === 0 && (
                  <p className="empty">Nenhuma consulta marcada</p>
                )}

                {consultas.map((c, i) => (
                  <div
                    className="estag-appointment-item"
                    key={`${c.data}-${c.hora}-${i}`}
                  >
                    <div className="patient-info">
                      <strong>{c.paciente}</strong>

                      <p>
                        {c.hora} • {c.sala}
                      </p>

                      <span className={`status-tag ${c.status}`}>
                        {c.status}
                      </span>
                    </div>

                    <div className="actions">
                      {c.status !== "Finalizado" && (
                        <button
                          className="btn-primary"
                          onClick={() => atualizarStatus(i)}
                        >
                          {c.status === "Agendado" ? "Iniciar" : "Finalizar"}
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
          {/* BANNER PREMIUM */}
          <div className="estag-banner-card">
            <img
              src="https://images.unsplash.com/photo-1582750433449-648ed127bb54?q=80&w=1200&auto=format&fit=crop"
              alt="Banner"
            />

            <div className="estag-banner-overlay">
              <h3>Continue seu excelente trabalho</h3>

              <p>Seus pacientes contam com você todos os dias.</p>
            </div>
          </div>

          {/* PERFIL */}
          {aba === "perfil" && (
            <div className="perfil-section">
              <h3>Meu Desempenho</h3>

              <div className="perfil-cards">
                <div className="perfil-card">
                  <p>Pacientes atendidos</p>

                  <strong>{totalPacientes()}</strong>
                </div>

                <div className="perfil-card">
                  <p>Avaliação média</p>

                  <strong>{calcularMedia()} ★</strong>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
