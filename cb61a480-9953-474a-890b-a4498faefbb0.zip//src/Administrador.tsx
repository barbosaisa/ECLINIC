import { useState } from "react";
import "./administrador.css";

export default function Administrador({ voltar, consultas, avaliacoes }) {
  const [aba, setAba] = useState("home");

  // =========================
  // DADOS
  // =========================
  const totalConsultas = consultas.length;

  const totalPacientes = [...new Set(consultas.map((c) => c.paciente))].length;

  const mediaGeral =
    avaliacoes.length > 0
      ? (
          avaliacoes.reduce((acc, a) => acc + a.nota, 0) / avaliacoes.length
        ).toFixed(1)
      : "0.0";

  // =========================
  // MENU
  // =========================
  const [menuAberto, setMenuAberto] = useState(false);

  // =========================
  // RANKING
  // =========================
  const ranking = Object.values(
    consultas.reduce((acc, c) => {
      if (!acc[c.estagiario]) {
        acc[c.estagiario] = {
          nome: c.estagiario,
          atendimentos: 0,
          notas: [],
        };
      }

      acc[c.estagiario].atendimentos++;

      const notas = avaliacoes
        .filter((a) => a.estagiario === c.estagiario)
        .map((a) => a.nota);

      acc[c.estagiario].notas = notas;

      return acc;
    }, {})
  ).map((e) => ({
    ...e,

    media: e.notas.length
      ? (e.notas.reduce((a, b) => a + b, 0) / e.notas.length).toFixed(1)
      : "0.0",
  }));

  return (
    <div className="admin-page">
      <div className="admin-wrapper">
        {/* SIDEBAR */}
        <div className={`admin-sidebar ${menuAberto ? "open" : ""}`}>
          <div className="admin-sidebar-top">
            <div className="admin-sidebar-logo">E</div>

            <div>
              <h3>Administrador</h3>

              <p>E-Clinic</p>
            </div>
          </div>

          <div className="admin-sidebar-links">
            <button
              className={
                aba === "home" ? "admin-side-link active" : "admin-side-link"
              }
              onClick={() => {
                setAba("home");
                setMenuAberto(false);
              }}
            >
              Dashboard
            </button>

            <button
              className={
                aba === "consultas"
                  ? "admin-side-link active"
                  : "admin-side-link"
              }
              onClick={() => {
                setAba("consultas");

                setMenuAberto(false);
              }}
            >
              Consultas
            </button>

            <button
              className={
                aba === "avaliacoes"
                  ? "admin-side-link active"
                  : "admin-side-link"
              }
              onClick={() => {
                setAba("avaliacoes");

                setMenuAberto(false);
              }}
            >
              Avaliações
            </button>

            <button className="admin-side-link logout" onClick={voltar}>
              Sair
            </button>
          </div>
        </div>

        {/* OVERLAY */}
        {menuAberto && (
          <div className="admin-overlay" onClick={() => setMenuAberto(false)} />
        )}

        {/* HEADER */}
        <header className="admin-header">
          <button
            className="admin-menu-button"
            onClick={() => setMenuAberto(true)}
          >
            ☰
          </button>

          <h2>Administrador</h2>
        </header>

        {/* MAIN */}
        <main className="admin-main">
          {/* DASHBOARD */}
          {aba === "home" && (
            <>
              <section className="admin-hero">
                <h2>Painel Geral</h2>

                <p>Visão completa da clínica</p>
              </section>

              {/* CARDS */}
              <div className="admin-grid">
                <div className="admin-card">
                  <strong>{totalPacientes}</strong>

                  <p>Pacientes</p>
                </div>

                <div className="admin-card">
                  <strong>{totalConsultas}</strong>

                  <p>Consultas</p>
                </div>

                <div className="admin-card">
                  <strong>{mediaGeral}</strong>

                  <p>Média Geral</p>
                </div>
              </div>

              {/* RANKING */}
              <div className="admin-section">
                <h3>Desempenho</h3>

                {ranking.map((e, i) => (
                  <div className="admin-item" key={i}>
                    <strong>{e.nome}</strong>

                    <p>{e.atendimentos} atendimentos</p>

                    <span>{e.media} ★</span>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* CONSULTAS */}
          {aba === "consultas" && (
            <div className="admin-section">
              <h3>Consultas</h3>

              {consultas.map((c, i) => (
                <div className="admin-item" key={i}>
                  <strong>{c.paciente}</strong>

                  <p>
                    {c.data}
                    {" • "}
                    {c.hora}
                  </p>

                  <small>{c.estagiario}</small>
                </div>
              ))}
            </div>
          )}

          {/* AVALIAÇÕES */}
          {aba === "avaliacoes" && (
            <div className="admin-section">
              <h3>Avaliações</h3>

              {avaliacoes.length === 0 && <p>Nenhuma avaliação</p>}

              {avaliacoes.map((a, i) => (
                <div className="admin-item" key={i}>
                  <strong>{a.estagiario}</strong>

                  <p>{a.comentario || "Sem comentário"}</p>

                  <span>{a.nota} ★</span>
                </div>
              ))}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
